def _hn(g, n):
    return g.nodes[n].get("hostname") or ""

def print_summary(g):
    rows = []
    for u, v, k, attrs in g.edges(keys=True, data=True):
        rows.append((attrs.get("protocol","?"), u, _hn(g,u), attrs.get("local_if","?"), v, _hn(g,v), attrs.get("remote_if","?")))

    print("\n--- Summary (links) ---")
    print(f"{'PROTO':<6} {'SRC':<16} {'SRC-HOST':<24} {'LOCAL-IF':<18} {'DST':<16} {'DST-HOST':<24} {'REMOTE-IF':<18}")
    print("-"*130)
    for (proto, src, sh, lif, dst, dh, rif) in rows:
        print(f"{proto:<6} {src:<16} {sh[:24]:<24} {lif[:18]:<18} {dst:<16} {dh[:24]:<24} {rif[:18]:<18}")

    eps = g.graph.get("endpoints") or []
    if eps:
        print(f"\nEndpoints discovered: {len(eps)} (written to topology.json meta.endpoints)")
