from dataclasses import dataclass
from typing import Dict, List, Tuple, Optional

from roland_discovery.snmp.ifmib import load_ifnames
from roland_discovery.snmp.cdp_addr import get_cdp_mgmt_addresses

CDP_DEV_ID_OID = "1.3.6.1.4.1.9.9.23.1.2.1.1.6"
CDP_DEV_PORT_OID = "1.3.6.1.4.1.9.9.23.1.2.1.1.7"

def _clean_value(v: str) -> str:
    if ":" in v:
        v = v.split(":", 1)[1].strip()
    return v.strip().strip('"')

def _parse_cdp_index(oid_str: str) -> Tuple[int, int]:
    parts = oid_str.split(".")
    device_index = int(parts[-1])
    if_index = int(parts[-2])
    return if_index, device_index

@dataclass(frozen=True)
class Neighbor:
    protocol: str
    local_if: str
    remote_device: str
    remote_port: str
    mgmt_ip: Optional[str] = None

def get_cdp_neighbors(snmp) -> List[Neighbor]:
    ifnames = load_ifnames(snmp)

    ids: Dict[Tuple[int, int], str] = {}
    ports: Dict[Tuple[int, int], str] = {}

    for oid, val in snmp.walk(CDP_DEV_ID_OID):
        ids[_parse_cdp_index(oid)] = _clean_value(val)

    for oid, val in snmp.walk(CDP_DEV_PORT_OID):
        ports[_parse_cdp_index(oid)] = _clean_value(val)

    mgmt = get_cdp_mgmt_addresses(snmp)

    neighbors: List[Neighbor] = []
    for (ifidx, devidx), dev in ids.items():
        neighbors.append(
            Neighbor(
                protocol="cdp",
                local_if=ifnames.get(ifidx, f"if{ifidx}"),
                remote_device=dev,
                remote_port=ports.get((ifidx, devidx), "unknown"),
                mgmt_ip=mgmt.get((ifidx, devidx)),
            )
        )
    return neighbors
