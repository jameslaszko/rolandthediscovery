from __future__ import annotations

from typing import Set, Dict

# ipAddrTable: ipAdEntAddr (deprecated but widely supported and simple)
# Each row's OID ends with the IPv4 address (a.b.c.d).
IPADENTADDR_OID = "1.3.6.1.2.1.4.20.1.1"
# ipAddrTable: ipAdEntIfIndex
IPADENTIFINDEX_OID = "1.3.6.1.2.1.4.20.1.2"

# IF-MIB: ifName
IFNAME_OID = "1.3.6.1.2.1.31.1.1.1.1"

def _parse_ipv4_from_oid(oid: str) -> str | None:
    parts = oid.split(".")
    if len(parts) < 4:
        return None
    try:
        a, b, c, d = (int(parts[-4]), int(parts[-3]), int(parts[-2]), int(parts[-1]))
    except ValueError:
        return None
    if not (0 <= a <= 255 and 0 <= b <= 255 and 0 <= c <= 255 and 0 <= d <= 255):
        return None
    return f"{a}.{b}.{c}.{d}"

def load_interface_ips(snmp) -> Set[str]:
    ips: Set[str] = set()
    for oid, _val in snmp.walk(IPADENTADDR_OID):
        ip = _parse_ipv4_from_oid(oid)
        if ip:
            ips.add(ip)
    return ips


def load_ip_to_ifname(snmp) -> Dict[str, str]:
    """Best-effort mapping of IPv4 address -> ifName.

    Uses ipAddrTable (ipAdEntIfIndex) + IF-MIB ifName.
    Works on many IOS/NX-OS platforms even when some bridge/Q-bridge tables are missing.
    """

    # Build ifIndex -> ifName
    ifindex_to_name: Dict[int, str] = {}
    for oid, val in snmp.walk(IFNAME_OID):
        try:
            ifindex = int(oid.split(".")[-1])
        except Exception:
            continue
        ifindex_to_name[ifindex] = str(val)

    ip_to_ifname: Dict[str, str] = {}
    for oid, val in snmp.walk(IPADENTIFINDEX_OID):
        ip = _parse_ipv4_from_oid(oid)
        if not ip:
            continue
        try:
            ifindex = int(str(val).strip())
        except Exception:
            continue
        name = ifindex_to_name.get(ifindex)
        if name:
            ip_to_ifname[ip] = name
    return ip_to_ifname
