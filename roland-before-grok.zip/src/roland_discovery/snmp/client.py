from __future__ import annotations

import os
import re
import subprocess
from typing import Iterable, Tuple

_LINE_RE = re.compile(r"^\s*\.?((?P<oid>[0-9]+(?:\.[0-9]+)*))\s*=\s*(?P<rest>.*)$")

class SnmpV2cClient:
    """SNMPv2c walker implemented via Net-SNMP 'snmpwalk' CLI."""

    def __init__(self, host: str, community: str, timeout: int = 2, retries: int = 1) -> None:
        self.host = host
        self.community = community
        self.timeout = timeout
        self.retries = retries

    def walk(self, oid: str, community: str | None = None) -> Iterable[Tuple[str, str]]:
        comm = community or self.community

        cmd = [
            "snmpwalk",
            "-v2c",
            "-c", comm,
            "-t", str(self.timeout),
            "-r", str(self.retries),
            "-On",
            self.host,
            oid,
        ]

        proc = subprocess.run(cmd, capture_output=True, text=True)

        if os.getenv("ROLAND_SNMP_DEBUG") == "1":
            print("DEBUG snmpwalk cmd:", " ".join(cmd))
            print("DEBUG returncode:", proc.returncode)
            print("DEBUG stdout:\n", proc.stdout)
            print("DEBUG stderr:\n", proc.stderr)

        if proc.returncode != 0:
            msg = (proc.stderr or proc.stdout or "").strip()
            raise RuntimeError(f"{self.host}: snmpwalk failed ({proc.returncode}): {msg}")

        parsed_any = False
        for line in (proc.stdout or "").splitlines():
            line = line.strip()
            if not line:
                continue
            m = _LINE_RE.match(line)
            if not m:
                if os.getenv("ROLAND_SNMP_DEBUG") == "1":
                    print("DEBUG unmatched line:", line)
                continue
            parsed_any = True
            yield m.group("oid"), m.group("rest")

        if not parsed_any:
            raise RuntimeError(f"{self.host}: snmpwalk output couldn't be parsed for OID {oid} (enable ROLAND_SNMP_DEBUG=1)")
