from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Dict, List, Optional, Any, Tuple


@dataclass
class ArpEntry:
    ip: str
    mac: str
    interface: str


@dataclass
class CdpDetailNeighbor:
    device_id: str
    ip: str
    local_interface: str
    port_id: str


def parse_show_ip_interface_brief(text: str) -> Dict[str, str]:
    """Return interface -> IP (best effort).

    Handles common Cisco IOS / IOS-XE / NX-OS formats.
    """
    out: Dict[str, str] = {}
    lines = [ln.rstrip() for ln in text.splitlines() if ln.strip()]
    if not lines:
        return out

    # Find the header line and skip it
    start = 0
    for i, ln in enumerate(lines[:10]):
        if "Interface" in ln and "IP" in ln:
            start = i + 1
            break

    for ln in lines[start:]:
        # Many variants are space-separated, but interface names never contain spaces.
        parts = re.split(r"\s+", ln.strip())
        if len(parts) < 2:
            continue
        iface = parts[0]
        ip = parts[1]
        if ip.lower() in {"unassigned", "-"}:
            continue
        if re.match(r"^\d+\.\d+\.\d+\.\d+$", ip):
            out[iface] = ip

    return out


def parse_show_arp(text: str) -> Dict[str, ArpEntry]:
    """Return ip -> ArpEntry (best effort)."""
    out: Dict[str, ArpEntry] = {}
    for ln in text.splitlines():
        line = ln.strip()
        if not line or line.lower().startswith("protocol"):
            continue

        # IOS: Internet  10.1.1.1            2   0011.2233.4455  ARPA  Vlan10
        # NX-OS: 10.1.1.1  00:11:22:33:44:55  Vlan10 ... (varies)
        parts = re.split(r"\s+", line)
        ip = None
        mac = None
        iface = None

        # Find first IPv4 in the line
        for p in parts:
            if re.match(r"^\d+\.\d+\.\d+\.\d+$", p):
                ip = p
                break
        if not ip:
            continue

        # Find a MAC-like token
        for p in parts:
            if re.match(r"^([0-9a-fA-F]{4}\.){2}[0-9a-fA-F]{4}$", p) or re.match(
                r"^([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}$", p
            ):
                mac = p
                break

        # Heuristic: interface is usually the last token
        iface = parts[-1] if len(parts) >= 2 else ""
        if ip and mac and iface:
            out[ip] = ArpEntry(ip=ip, mac=mac, interface=iface)

    return out


def parse_cdp_neighbors_detail(text: str) -> List[CdpDetailNeighbor]:
    """Parse 'show cdp neighbors detail' into structured neighbors."""
    # Split by blank lines; many platforms separate entries by one or more blank lines.
    blocks = re.split(r"\n\s*\n", text.strip(), flags=re.MULTILINE)
    out: List[CdpDetailNeighbor] = []

    def grab(patterns: List[str], block: str) -> Optional[str]:
        for pat in patterns:
            m = re.search(pat, block, flags=re.IGNORECASE | re.MULTILINE)
            if m:
                return m.group(1).strip()
        return None

    for b in blocks:
        if "Device ID" not in b and "Device-ID" not in b:
            continue

        device_id = grab([r"Device ID\s*:\s*(.+)", r"Device-ID\s*:\s*(.+)"], b) or ""
        ip = grab(
            [
                r"IP address\s*:\s*(\d+\.\d+\.\d+\.\d+)",
                r"IPv4 Address\s*:\s*(\d+\.\d+\.\d+\.\d+)",
                r"Management address\(es\).*?IP address\s*:\s*(\d+\.\d+\.\d+\.\d+)",
            ],
            b,
        ) or ""
        local_intf = grab(
            [
                r"Interface\s*:\s*([^,\n]+)",
                r"Local Interface\s*:\s*([^,\n]+)",
            ],
            b,
        ) or ""
        port_id = grab(
            [
                r"Port ID \(outgoing port\)\s*:\s*(.+)",
                r"Port ID\s*:\s*(.+)",
            ],
            b,
        ) or ""

        if device_id and local_intf:
            out.append(CdpDetailNeighbor(device_id=device_id, ip=ip, local_interface=local_intf, port_id=port_id))

    return out


# Backwards-compatible alias (older build.py versions imported this name)
parse_show_cdp_neighbors_detail = parse_cdp_neighbors_detail


# -----------------------------
# Switching / VLAN catalog
# -----------------------------


def _parse_vlan_list(v: str) -> List[int]:
    """Parse VLAN lists like '1,10,20-30' into ints (best-effort)."""
    v = (v or "").strip()
    if not v or v.lower() in {"none", "all"}:
        return []
    out: List[int] = []
    for part in v.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            try:
                a_i = int(a)
                b_i = int(b)
            except Exception:
                continue
            if a_i <= b_i:
                out.extend(list(range(a_i, b_i + 1)))
        else:
            try:
                out.append(int(part))
            except Exception:
                continue
    return sorted(set(out))


def parse_show_vlan_brief(text: str) -> Dict[int, str]:
    """Return {vlan_id: vlan_name} from `show vlan brief` output."""
    vlans: Dict[int, str] = {}
    for line in (text or "").splitlines():
        line = line.rstrip()
        if not line or line.lower().startswith("vlan") or line.startswith("----"):
            continue
        m = re.match(r"^(\d+)\s+([^\s]+)\s+", line)
        if not m:
            continue
        try:
            vid = int(m.group(1))
        except Exception:
            continue
        vlans[vid] = m.group(2)
    return vlans


def parse_show_interfaces_trunk(text: str) -> Dict[str, Dict[str, Any]]:
    """Parse `show interfaces trunk` / `show interface trunk` (IOS/NX-OS best-effort)."""
    trunks: Dict[str, Dict[str, Any]] = {}
    lines = (text or "").splitlines()

    allowed_mode = False
    for ln in lines:
        s = ln.strip()
        if not s:
            continue
        if re.search(r"Vlans\s+allowed\s+on\s+trunk", s, re.IGNORECASE):
            allowed_mode = True
            continue
        if allowed_mode:
            m = re.match(r"^(\S+)\s+(.+)$", s)
            if not m:
                allowed_mode = False
                continue
            iface = m.group(1)
            vlan_str = m.group(2).strip()
            trunks.setdefault(iface, {})["allowed_vlans"] = _parse_vlan_list(vlan_str)

    # Native VLAN table (IOS style)
    for ln in lines:
        s = ln.strip()
        if not s or s.lower().startswith("port"):
            continue
        m = re.match(r"^(\S+)\s+\S+\s+\S+\s+\S+\s+(\d+)\s*$", s)
        if not m:
            continue
        iface = m.group(1)
        try:
            native = int(m.group(2))
        except Exception:
            native = None
        trunks.setdefault(iface, {})["native_vlan"] = native
    return trunks


def parse_show_interfaces_switchport(text: str) -> Dict[str, Dict[str, Any]]:
    """Parse `show interfaces switchport` (IOS/NX-OS)."""
    out: Dict[str, Dict[str, Any]] = {}
    cur_if: Optional[str] = None
    buf: List[str] = []

    def flush():
        nonlocal cur_if, buf
        if not cur_if:
            buf = []
            return
        blob = "\n".join(buf)
        d: Dict[str, Any] = {}
        m = re.search(r"Operational Mode:\s*(.+)$", blob, re.MULTILINE)
        if not m:
            m = re.search(r"Administrative Mode:\s*(.+)$", blob, re.MULTILINE)
        mode = (m.group(1).strip().lower() if m else "unknown")
        if "trunk" in mode:
            d["mode"] = "trunk"
        elif "access" in mode:
            d["mode"] = "access"
        elif "dynamic" in mode:
            d["mode"] = "dynamic"
        else:
            d["mode"] = "unknown"

        m = re.search(r"Access Mode VLAN:\s*(\d+)", blob)
        if m:
            d["access_vlan"] = int(m.group(1))
        m = re.search(r"Trunking Native Mode VLAN:\s*(\d+)", blob)
        if m:
            d["native_vlan"] = int(m.group(1))
        m = re.search(r"Trunking VLANs Enabled:\s*(.+)$", blob, re.MULTILINE)
        if m:
            d["trunk_vlans"] = _parse_vlan_list(m.group(1).strip())

        out[cur_if] = d
        buf = []

    for ln in (text or "").splitlines():
        if ln and not ln.startswith(" ") and ":" not in ln and re.match(r"^[A-Za-z].*\d", ln.strip()):
            flush()
            cur_if = ln.strip()
            buf = []
            continue
        if cur_if is not None:
            buf.append(ln.rstrip())
    flush()
    return out


def collect_switching_catalog(ssh) -> Dict[str, Any]:
    """Collect VLAN/trunk/access inventory over SSH (best-effort)."""

    def run(cmds: List[str]) -> Tuple[str, str]:
        for c in cmds:
            out = ssh.exec(c)
            if out and "Invalid" not in out and "ERROR" not in out and "Unknown" not in out:
                return c, out
        return cmds[0], ""

    used_vlan_cmd, vlan_txt = run(["show vlan brief", "show vlan"])
    used_trunk_cmd, trunk_txt = run(["show interfaces trunk", "show interface trunk"])
    used_sw_cmd, sw_txt = run(["show interfaces switchport", "show interface switchport"])

    return {
        "commands": {
            "vlan": used_vlan_cmd,
            "trunk": used_trunk_cmd,
            "switchport": used_sw_cmd,
        },
        "vlans": parse_show_vlan_brief(vlan_txt) if vlan_txt else {},
        "trunks": parse_show_interfaces_trunk(trunk_txt) if trunk_txt else {},
        "switchports": parse_show_interfaces_switchport(sw_txt) if sw_txt else {},
    }
