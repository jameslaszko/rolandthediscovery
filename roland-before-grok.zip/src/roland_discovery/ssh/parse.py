from __future__ import annotations

import re
from typing import List, Set, Tuple

_IPV4_RE = re.compile(r"\b(\d{1,3}(?:\.\d{1,3}){3})\b")


def extract_ipv4s(text: str) -> Set[str]:
    """Extract IPv4-like tokens (best-effort)."""
    ips = set()
    for m in _IPV4_RE.finditer(text or ""):
        ip = m.group(1)
        parts = ip.split('.')
        if len(parts) == 4 and all(p.isdigit() and 0 <= int(p) <= 255 for p in parts):
            ips.add(ip)
    return ips


def parse_show_ip_interface_brief(output: str) -> Set[str]:
    """Return interface IPs from IOS/NX-OS-ish 'show ip interface brief' output."""
    ips = set()
    for line in (output or "").splitlines():
        if "unassigned" in line.lower():
            continue
        # common formats put IP in 2nd column
        for ip in extract_ipv4s(line):
            ips.add(ip)
    return ips
