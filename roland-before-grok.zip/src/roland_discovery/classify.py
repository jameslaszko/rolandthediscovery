from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

@dataclass(frozen=True)
class DeviceClass:
    vendor: str = "unknown"
    family: str = "unknown"   # catalyst, nexus, ie2000, axis, etc
    role: str = "unknown"     # switch, router, endpoint, camera, unknown

def classify_device(sysdescr: Optional[str], hostname: Optional[str]) -> DeviceClass:
    """Best-effort device classification from sysDescr and hostname.

    This is intentionally heuristic and vendor-biased for Cisco environments.
    """
    hn = (hostname or "").strip().lower()
    sd = (sysdescr or "").strip().lower()

    # Hostname-based excludes
    if hn.startswith("axis"):
        return DeviceClass(vendor="axis", family="axis", role="camera")

    # Cisco Nexus / NX-OS
    if "nx-os" in sd or "nexus" in sd or " n5000" in sd or "n5000-" in sd:
        return DeviceClass(vendor="cisco", family="nexus", role="switch")

    # Cisco IE2x00
    if "ie2000" in sd or "ie2" in sd and "ie2000" in sd:
        return DeviceClass(vendor="cisco", family="ie2000", role="switch")

    # Catalyst 3k / IOS-XE
    if "ios-xe" in sd or "cat3k" in sd or "catalyst l3 switch" in sd:
        return DeviceClass(vendor="cisco", family="catalyst", role="switch")

    # Generic Cisco IOS (could be router or switch)
    if "cisco ios software" in sd or "ios software" in sd:
        return DeviceClass(vendor="cisco", family="ios", role="switch")

    return DeviceClass()
